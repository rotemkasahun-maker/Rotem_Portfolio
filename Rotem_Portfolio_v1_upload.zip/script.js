document.addEventListener("DOMContentLoaded", () => {
  const focusBlocks = [...document.querySelectorAll("[data-focus-block]")];

  if (!window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
    const updateFocus = () => {
      const center = window.innerHeight / 2;
      focusBlocks.forEach((block) => {
        const lines = [...block.querySelectorAll(".focus-line")];
        let active = 0;
        let best = Infinity;

        lines.forEach((line, index) => {
          const rect = line.getBoundingClientRect();
          const distance = Math.abs(rect.top + rect.height / 2 - center);
          if (distance < best) {
            best = distance;
            active = index;
          }
        });

        lines.forEach((line, index) => {
          line.classList.toggle("is-active", index === active);
          line.classList.toggle("is-near", Math.abs(index - active) === 1);
        });
      });
    };

    let ticking = false;
    const requestFocusUpdate = () => {
      if (ticking) return;
      ticking = true;
      requestAnimationFrame(() => {
        updateFocus();
        ticking = false;
      });
    };

    window.addEventListener("scroll", requestFocusUpdate, { passive: true });
    window.addEventListener("resize", requestFocusUpdate);
    updateFocus();
  } else {
    focusBlocks.forEach((block) => {
      block.querySelectorAll(".focus-line").forEach((line) => {
        line.classList.add("is-active");
      });
    });
  }
});
